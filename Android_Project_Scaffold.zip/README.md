# Smart Pantry Manager — Android Java project scaffold

Student: Jacueline Mama Motapanyane
Student number: 402307174

## What is included
A native Android Java scaffold with:
- One activity and a simple pantry list interface
- SQLite local persistence for pantry items
- Add/delete pantry item controls
- Strict recipe matching model and sample recipe data
- A starter report, test checklist and demo script are in the separate rescue bundle

## Important status
This source scaffold has not been built or run in Android Studio in this environment. It is not verified submission-ready. Open it in Android Studio on a computer, let Gradle sync, build and run, then fix any issues and add genuine screenshots. The user's phone alone may not be sufficient to compile a native Android APK.

## Build
Open this folder in Android Studio. Use a compatible installed Android Gradle Plugin / Gradle version if your Android Studio recommends an update. The project uses Java 17 and Android SDK 35.

## Core rule
A recipe is suggested only when every required ingredient is present and sufficient in quantity. A partial match is rejected.
