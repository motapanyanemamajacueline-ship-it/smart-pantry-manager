package za.co.smartpantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class PantryDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "smart_pantry.db";
    private static final int DB_VERSION = 1;

    public PantryDb(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pantry (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Add explicit migrations here if the schema changes in a future version.
    }

    public long addItem(String name, double quantity, String unit) {
        ContentValues values = new ContentValues();
        values.put("name", name.trim()); values.put("quantity", quantity); values.put("unit", unit.trim());
        return getWritableDatabase().insert("pantry", null, values);
    }

    public List<PantryItem> getItems() {
        List<PantryItem> items = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,name,quantity,unit FROM pantry ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) items.add(new PantryItem(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3)));
        }
        return items;
    }

    public int deleteItem(long id) {
        return getWritableDatabase().delete("pantry", "id=?", new String[]{String.valueOf(id)});
    }
}
