package za.co.smartpantry;

public class PantryItem {
    public final long id;
    public final String name;
    public final double quantity;
    public final String unit;

    public PantryItem(long id, String name, double quantity, String unit) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
    }
}
