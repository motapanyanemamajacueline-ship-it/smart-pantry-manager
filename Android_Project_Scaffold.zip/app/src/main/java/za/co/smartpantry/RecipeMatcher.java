package za.co.smartpantry;

import java.util.List;
import java.util.Locale;

public final class RecipeMatcher {
    private RecipeMatcher() {}

    private static String norm(String value) {
        String s = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        if (s.endsWith("ies") && s.length() > 4) return s.substring(0, s.length()-3) + "y";
        if (s.endsWith("s") && !s.endsWith("ss") && s.length() > 3) return s.substring(0, s.length()-1);
        return s;
    }

    public static boolean canMake(Recipe recipe, List<PantryItem> pantry) {
        for (Recipe.Requirement need : recipe.requirements) {
            boolean found = false;
            for (PantryItem item : pantry) {
                boolean nameMatches = norm(item.name).equals(norm(need.name));
                boolean unitMatches = item.unit != null && need.unit != null
                        && item.unit.trim().equalsIgnoreCase(need.unit.trim());
                if (nameMatches && unitMatches && item.quantity >= need.quantity) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }
}
