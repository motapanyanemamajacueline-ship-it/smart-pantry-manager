package za.co.smartpantry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class RecipeBook {
    private RecipeBook() {}
    private static Recipe.Requirement r(String n, double q, String u) { return new Recipe.Requirement(n,q,u); }

    public static List<Recipe> all() {
        List<Recipe> list = new ArrayList<>();
        list.add(new Recipe("Tomato Egg Scramble", Arrays.asList(r("egg",2,"each"),r("tomato",1,"each"),r("oil",5,"ml")), "Beat eggs. Chop tomato. Warm oil in a pan, soften tomato, add eggs and stir until cooked."));
        list.add(new Recipe("Cheese Toast", Arrays.asList(r("bread",2,"slice"),r("cheese",30,"g")), "Place cheese on bread and toast until hot and melted."));
        list.add(new Recipe("Banana Oats", Arrays.asList(r("oats",50,"g"),r("milk",200,"ml"),r("banana",1,"each")), "Cook oats with milk and top with sliced banana."));
        list.add(new Recipe("Garlic Pasta", Arrays.asList(r("pasta",100,"g"),r("garlic",1,"clove"),r("oil",10,"ml")), "Boil pasta. Gently warm chopped garlic in oil, then toss with drained pasta."));
        list.add(new Recipe("Potato Hash", Arrays.asList(r("potato",2,"each"),r("onion",1,"each"),r("oil",10,"ml")), "Dice potato and onion. Pan-cook in oil until tender and golden."));
        list.add(new Recipe("Peanut Banana Toast", Arrays.asList(r("bread",2,"slice"),r("peanut butter",20,"g"),r("banana",1,"each")), "Spread peanut butter on toast and add sliced banana."));
        list.add(new Recipe("Simple Rice and Beans", Arrays.asList(r("rice",100,"g"),r("beans",150,"g")), "Cook rice. Heat cooked beans and serve together."));
        list.add(new Recipe("Tuna Pasta", Arrays.asList(r("pasta",100,"g"),r("tuna",1,"can"),r("mayonnaise",15,"g")), "Cook and cool pasta slightly, then mix with drained tuna and mayonnaise."));
        list.add(new Recipe("Carrot Soup", Arrays.asList(r("carrot",3,"each"),r("onion",1,"each"),r("stock",500,"ml")), "Simmer chopped carrot and onion in stock until soft, then blend carefully."));
        list.add(new Recipe("Apple Oat Bowl", Arrays.asList(r("oats",50,"g"),r("apple",1,"each"),r("yoghurt",100,"g")), "Serve oats with chopped apple and yoghurt."));
        list.add(new Recipe("Cheese Omelette", Arrays.asList(r("egg",2,"each"),r("cheese",25,"g")), "Beat eggs, cook in a non-stick pan and add cheese before folding."));
        list.add(new Recipe("Tomato Rice", Arrays.asList(r("rice",100,"g"),r("tomato",2,"each"),r("onion",1,"each")), "Cook rice. Simmer chopped tomato and onion, then combine."));
        list.add(new Recipe("Spinach Eggs", Arrays.asList(r("egg",2,"each"),r("spinach",50,"g"),r("oil",5,"ml")), "Wilt spinach in oil, add beaten eggs and cook through."));
        list.add(new Recipe("Yoghurt Fruit Bowl", Arrays.asList(r("yoghurt",150,"g"),r("banana",1,"each"),r("apple",1,"each")), "Chop fruit and serve over yoghurt."));
        list.add(new Recipe("Garlic Potato Wedges", Arrays.asList(r("potato",2,"each"),r("garlic",1,"clove"),r("oil",10,"ml")), "Cut potatoes into wedges, coat with oil and garlic, then bake until tender."));
        list.add(new Recipe("Bean Toast", Arrays.asList(r("bread",2,"slice"),r("beans",150,"g")), "Heat cooked beans and spoon over toasted bread."));
        return list;
    }
}
