package za.co.smartpantry;

import java.util.List;

public class Recipe {
    public final String name;
    public final List<Requirement> requirements;
    public final String method;

    public Recipe(String name, List<Requirement> requirements, String method) {
        this.name = name;
        this.requirements = requirements;
        this.method = method;
    }

    public static class Requirement {
        public final String name;
        public final double quantity;
        public final String unit;
        public Requirement(String name, double quantity, String unit) {
            this.name = name; this.quantity = quantity; this.unit = unit;
        }
    }
}
