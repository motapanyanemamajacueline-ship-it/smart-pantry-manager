package za.co.smartpantry;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private PantryDb db;
    private LinearLayout content;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new PantryDb(this);
        showPantry();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(listener); return b;
    }

    private void base(String title) {
        LinearLayout outer = new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16),dp(18),dp(16),dp(12));
        outer.addView(text("SMART PANTRY MANAGER", 12));
        outer.addView(text(title, 25));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(outer);
    }

    private void showPantry() {
        base("My Pantry");
        content.addView(button("+ Add ingredient", v -> addDialog()));
        content.addView(button("Find matching recipes", v -> showRecipes()));
        List<PantryItem> items = db.getItems();
        if (items.isEmpty()) content.addView(text("Your pantry is empty. Add an ingredient to begin.",16));
        for (PantryItem item : items) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = text(item.name + " — " + item.quantity + " " + item.unit,16);
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(button("Delete",v -> new AlertDialog.Builder(this)
                    .setTitle("Delete ingredient?")
                    .setMessage("Remove " + item.name + " from your pantry?")
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Delete",(d,w) -> { db.deleteItem(item.id); showPantry(); })
                    .show()));
            content.addView(row);
        }
    }

    private void addDialog() {
        LinearLayout form = new LinearLayout(this); form.setPadding(dp(12),dp(4),dp(12),dp(4)); form.setOrientation(LinearLayout.VERTICAL);
        EditText name = new EditText(this); name.setHint("Ingredient name"); form.addView(name);
        EditText quantity = new EditText(this); quantity.setHint("Quantity (positive number)"); quantity.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); form.addView(quantity);
        EditText unit = new EditText(this); unit.setHint("Unit (e.g. each, g, ml)"); form.addView(unit);
        new AlertDialog.Builder(this).setTitle("Add pantry ingredient").setView(form)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(d,w) -> {
                String n=name.getText().toString().trim(), u=unit.getText().toString().trim();
                double q;
                try { q=Double.parseDouble(quantity.getText().toString().trim()); }
                catch (Exception ex) { Toast.makeText(this,"Enter a valid positive quantity.",Toast.LENGTH_LONG).show(); return; }
                if(n.isEmpty() || u.isEmpty() || q<=0) { Toast.makeText(this,"Name and unit are required; quantity must be positive.",Toast.LENGTH_LONG).show(); return; }
                db.addItem(n,q,u); showPantry();
            }).show();
    }

    private void showRecipes() {
        base("Matching Recipes");
        List<PantryItem> pantry = db.getItems();
        List<Recipe> matches = new ArrayList<>();
        for (Recipe recipe : RecipeBook.all()) if (RecipeMatcher.canMake(recipe, pantry)) matches.add(recipe);
        content.addView(button("← Back to pantry",v -> showPantry()));
        content.addView(text("Strict matching: all ingredients and required quantities must be available.",14));
        if(matches.isEmpty()) content.addView(text("No recipes match your current pantry. Add ingredients or quantities and try again.",16));
        for(Recipe recipe:matches) {
            content.addView(button(recipe.name,v -> new AlertDialog.Builder(this)
                    .setTitle(recipe.name)
                    .setMessage(recipe.method + "\n\nRequired ingredients:\n" + requirements(recipe))
                    .setPositiveButton("Close",null).show()));
        }
    }

    private String requirements(Recipe recipe) {
        StringBuilder s=new StringBuilder();
        for(Recipe.Requirement r:recipe.requirements) s.append("• ").append(r.name).append(": ").append(r.quantity).append(" ").append(r.unit).append("\n");
        return s.toString();
    }

    @Override protected void onDestroy() { super.onDestroy(); if(db!=null) db.close(); }
}
